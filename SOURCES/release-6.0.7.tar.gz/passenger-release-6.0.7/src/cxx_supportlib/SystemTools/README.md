This directory contains general operating system utility code.
